<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitar Cita</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 400px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
        }
        label {
            display: block;
            margin: 10px 0 5px;
        }
        select, input {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Solicitar Cita</h1>
    <form action="#">
        <label for="mujer">Selecciona una mujer:</label>
        <select id="mujer" required>
            <option value="">--Elige una--</option>
            <option value="mujer1">Mujer 1</option>
            <option value="mujer2">Mujer 2</option>
            <option value="mujer3">Mujer 3</option>
            <option value="mujer4">Mujer 4</option>
            <option value="mujer5">Mujer 5</option>
            <option value="mujer6">Mujer 6</option>
            <option value="mujer7">Mujer 7</option>
            <option value="mujer8">Mujer 8</option>
        </select>

        <label for="nombre">Tu Nombre:</label>
        <input type="text" id="nombre" required>
        
        <label for="fecha">Fecha de la Cita:</label>
        <input type="date" id="fecha" required>
        
        <label for="hora">Hora de la Cita:</label>
        <input type="time" id="hora" required>
        
        <button type="submit">Confirmar Cita</button>
    </form>
</div>

</body>
</html>
