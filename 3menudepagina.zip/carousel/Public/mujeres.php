<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prostíbulo</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            margin: 15px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center my-5">Selecciona a tu Compañera</h1>

    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <img src="https://via.placeholder.com/300" class="card-img-top" alt="Mujer 1">
                <div class="card-body">
                    <h5 class="card-title">Mujer 1</h5>
                    <p class="card-text">Descripción: Una hermosa mujer con una sonrisa cautivadora y un carácter encantador. Siempre lista para hacer que tu noche sea inolvidable.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="https://via.placeholder.com/300" class="card-img-top" alt="Mujer 2">
                <div class="card-body">
                    <h5 class="card-title">Mujer 2</h5>
                    <p class="card-text">Descripción: Elegante y sofisticada, su porte y encanto te dejarán sin palabras. Ideal para disfrutar de una velada especial.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="https://via.placeholder.com/300" class="card-img-top" alt="Mujer 3">
                <div class="card-body">
                    <h5 class="card-title">Mujer 3</h5>
                    <p class="card-text">Descripción: Apasionada y extrovertida, tiene un espíritu libre que ilumina cualquier habitación. Perfecta para quienes buscan diversión.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="https://via.placeholder.com/300" class="card-img-top" alt="Mujer 4">
                <div class="card-body">
                    <h5 class="card-title">Mujer 4</h5>
                    <p class="card-text">Descripción: Dulce y cariñosa, su calidez te hará sentir como en casa. Ideal para quienes buscan compañía y conversación.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="https://via.placeholder.com/300" class="card-img-top" alt="Mujer 5">
                <div class="card-body">
                    <h5 class="card-title">Mujer 5</h5>
                    <p class="card-text">Descripción: Una mujer con un toque misterioso, su mirada profunda y su carisma te atraparán. Perfecta para quienes buscan emoción.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="https://via.placeholder.com/300" class="card-img-top" alt="Mujer 6">
                <div class="card-body">
                    <h5 class="card-title">Mujer 6</h5>
                    <p class="card-text">Descripción: Atlética y enérgica, siempre lista para la aventura. Ideal para quienes disfrutan de actividades y diversión dinámica.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="https://via.placeholder.com/300" class="card-img-top" alt="Mujer 7">
                <div class="card-body">
                    <h5 class="card-title">Mujer 7</h5>
                    <p class="card-text">Descripción: Sofisticada y refinada, su estilo y gracia son incomparables. Perfecta para cenas elegantes y eventos exclusivos.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="https://via.placeholder.com/300" class="card-img-top" alt="Mujer 8">
                <div class="card-body">
                    <h5 class="card-title">Mujer 8</h5>
                    <p class="card-text">Descripción: Creativa y artística, siempre trae un aire fresco y original. Ideal para quienes buscan algo diferente y emocionante.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
