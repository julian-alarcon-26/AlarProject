<?php
require "../config/conexion.php";
$doc = $_POST["doc"];
$sql = "DELETE FROM
usuarios
WHERE 
documento = ".$doc." ";
if($dbh->query($sql))
{
echo "exito";
}else
{
echo "error";
}
?>
