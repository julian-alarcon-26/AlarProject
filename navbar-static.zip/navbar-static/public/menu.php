<nav class="navbar navbar-expand-md navbar-dark bg-dark mb-4">
  <div class="container-fluid">
<nav class="d-inline-flex mt-2 mt-md-0 ms-md-auto">
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="index.php">Inicio</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="registrar.php">Registrar Usuario</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="consultar.php">Consultar Usuario</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="editar.php">Editar Usuario</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="eliminar.php">Eliminar Usuario</a>
      </nav>
</div>