<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventos de Boxeo</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        h1 {
            color: #007bff;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center">Próximos Eventos de Boxeo</h1>

    <ul class="list-group">
        <li class="list-group-item">
            <h5>Campeonato Mundial</h5>
            <p>Fecha: 15 de Octubre 2024</p>
            <p>Ubicación: Estadio Nacional, Ciudad de México</p>
        </li>
        <li class="list-group-item">
            <h5>Liga Profesional de Boxeo</h5>
            <p>Fecha: 22 de Octubre 2024</p>
            <p>Ubicación: Arena Coliseo, Guadalajara</p>
        </li>
        <li class="list-group-item">
            <h5>Noche de Boxeo</h5>
            <p>Fecha: 29 de Octubre 2024</p>
            <p>Ubicación: Palacio de los Deportes, Monterrey</p>
        </li>
        <li class="list-group-item">
            <h5>Torneo de Boxeo Amateur</h5>
            <p>Fecha: 5 de Noviembre 2024</p>
            <p>Ubicación: Gimnasio Municipal, Tijuana</p>
        </li>
    </ul>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
