<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscripción a Evento de Boxeo</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #e9ecef;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 50px;
            background-color: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #ff5733;
            margin-bottom: 30px;
        }
        .btn-boxing {
            background-color: #ff5733;
            color: white;
        }
        .btn-boxing:hover {
            background-color: #c70039;
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center">Inscríbete en Nuestro Evento de Boxeo</h1>
    <form action="#" method="post">
        <div class="form-group">
            <label for="name">Nombre Completo:</label>
            <input type="text" class="form-control" id="name" name="name" placeholder="Ingresa tu nombre completo" required>
        </div>
        <div class="form-group">
            <label for="email">Correo Electrónico:</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="tu.email@example.com" required>
        </div>
        <div class="form-group">
            <label for="tel">Teléfono:</label>
            <input type="tel" class="form-control" id="tel" name="tel" placeholder="Tu número de teléfono" required>
        </div>
        <div class="form-group">
            <label for="age">Edad:</label>
            <input type="number" class="form-control" id="age" name="age" placeholder="Tu edad" required>
        </div>
        <div class="form-group">
            <label>Género:</label><br>
            <input type="radio" id="male" name="gender" value="masculino" required>
            <label for="male">Masculino</label>
            <input type="radio" id="female" name="gender" value="femenino" required>
            <label for="female">Femenino</label>
        </div>
        <button type="submit" class="btn btn-boxing btn-block">Inscribirse</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
