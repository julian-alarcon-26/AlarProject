<?php
$total = $_POST["total"];
$descripcion = $_POST["desc"];
if($total > 0 and $total <=100000)

{
echo "total: ".$total;
echo "<br> descripcion: ".$descripcion;
}else
{
  echo "valor invalido";
}
?>