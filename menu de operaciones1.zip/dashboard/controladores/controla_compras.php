<?php
$cantidad = $_POST["cant"];
$total = $cantidad * 2500;
if($total > 0 and $total <100000)
{
echo "el total a pagar es : ".$total;
}else
{
  echo "valor no valido";
}
?>