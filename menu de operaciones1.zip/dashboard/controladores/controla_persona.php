<?php
$nomre = $_POST["nombre"]; 
$documento = $_POST["doc"]; 
$edad = $_POST["edad"];
if($edad >= 18)
{
echo "nombre: ".$nombre;
echo "doc: ".$documento;
echo "edad: ".$documento;
}else
{
  echo "chao";
}
?>