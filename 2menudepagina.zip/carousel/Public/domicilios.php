<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panes a Domicilio</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        h1 {
            color: #007bff;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center my-5">Panes a Domicilio</h1>

    <h2>Selecciona tu Pan:</h2>
    <ul>
        <li>Pan Francés</li>
        <li>Pan Integral</li>
        <li>Pan de Ajo</li>
        <li>Pan de Centeno</li>
        <li>Pan de Chocolate</li>
    </ul>

    <h2 class="mt-5">Realiza tu Pedido</h2>
    <form action="#" method="post">
        <div class="form-group">
            <label for="name">Nombre Completo:</label>
            <input type="text" id="name" name="name" class="form-control" required placeholder="Tu nombre completo">
        </div>
        <div class="form-group">
            <label for="address">Dirección de Entrega:</label>
            <input type="text" id="address" name="address" class="form-control" required placeholder="Tu dirección">
        </div>
        <div class="form-group">
            <label for="email">Correo Electrónico:</label>
            <input type="email" id="email" name="email" class="form-control" required placeholder="Tu correo electrónico">
        </div>
        <div class="form-group">
            <label for="phone">Teléfono:</label>
            <input type="tel" id="phone" name="phone" class="form-control" required placeholder="Tu número de teléfono">
        </div>
        <div class="form-group">
            <label for="breadType">Tipo de Pan:</label>
            <select id="breadType" name="breadType" class="form-control" required>
                <option value="">Selecciona un tipo de pan</option>
                <option value="francés">Pan Francés</option>
                <option value="integral">Pan Integral</option>
                <option value="ajo">Pan de Ajo</option>
                <option value="centeno">Pan de Centeno</option>
                <option value="chocolate">Pan de Chocolate</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Enviar Pedido</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

