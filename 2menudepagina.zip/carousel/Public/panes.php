<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tipos de Pan</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        h1 {
            color: #6f42c1;
            margin-bottom: 30px;
        }
        .pan-card {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center">Tipos de Pan a la Venta</h1>

    <div class="card pan-card">
        <div class="card-body">
            <h5 class="card-title">Pan Francés</h5>
            <p class="card-text">Un clásico crujiente por fuera y suave por dentro, ideal para acompañar cualquier comida.</p>
        </div>
    </div>

    <div class="card pan-card">
        <div class="card-body">
            <h5 class="card-title">Pan Integral</h5>
            <p class="card-text">Hecho con harina integral, perfecto para quienes buscan una opción más saludable.</p>
        </div>
    </div>

    <div class="card pan-card">
        <div class="card-body">
            <h5 class="card-title">Pan de Centeno</h5>
            <p class="card-text">Con un sabor distintivo y una textura densa, excelente para sándwiches.</p>
        </div>
    </div>

    <div class="card pan-card">
        <div class="card-body">
            <h5 class="card-title">Baguette</h5>
            <p class="card-text">Un pan alargado y crujiente, perfecto para hacer deliciosos sándwiches.</p>
        </div>
    </div>

    <div class="card pan-card">
        <div class="card-body">
            <h5 class="card-title">Pan de Molde</h5>
            <p class="card-text">Suave y esponjoso, ideal para tostadas y sándwiches.</p>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
